﻿namespace $safeprojectname$;

using Microsoft.Extensions.DependencyInjection;

public static class ServicesConfiguration
{
    public static void RegisterService(this IServiceCollection services)
    {
        // TODO: Register services
    }
}

